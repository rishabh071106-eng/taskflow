const CACHE = 'taskflow-v1';
const ASSETS = ['/', '/index.html', '/manifest.json'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request).then(res => {
      if (res.ok && e.request.method === 'GET') {
        caches.open(CACHE).then(c => c.put(e.request, res.clone()));
      }
      return res;
    })).catch(() => e.request.destination === 'document' ? caches.match('/') : undefined)
  );
});

self.addEventListener('message', e => {
  if (e.data?.type === 'REMINDER') {
    const t = e.data.task;
    self.registration.showNotification('⏰ TaskFlow Reminder', {
      body: t.title + (t.notes ? '\n' + t.notes : ''),
      tag: t.id,
      data: t,
      actions: [
        { action: 'whatsapp', title: '📱 WhatsApp' },
        { action: 'done', title: '✅ Done' }
      ],
      vibrate: [200, 100, 200],
      requireInteraction: true
    });
  }
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  const t = e.notification.data;
  if (e.action === 'whatsapp' && t) {
    const num = localStorage.getItem('tf_wa_num') || '';
    const msg = `📋 Task: ${t.title}${t.notes ? '\n' + t.notes : ''}${t.dueDate ? '\n📅 ' + t.dueDate : ''}`;
    e.waitUntil(clients.openWindow(`https://wa.me/${num}?text=${encodeURIComponent(msg)}`));
  } else if (e.action === 'done' && t) {
    e.waitUntil(clients.matchAll({ type: 'window' }).then(cs => {
      cs.forEach(c => c.postMessage({ type: 'MARK_DONE', id: t.id }));
      if (cs[0]) cs[0].focus(); else clients.openWindow('/');
    }));
  } else {
    e.waitUntil(clients.matchAll({ type: 'window' }).then(cs => {
      if (cs[0]) cs[0].focus(); else clients.openWindow('/');
    }));
  }
});
