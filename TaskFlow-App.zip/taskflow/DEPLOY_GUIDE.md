# TaskFlow — Deployment & Play Store Guide

## 🚀 Step 1: Go Live TODAY (15 minutes)

### Option A: Netlify (Recommended — drag & drop)
1. Go to **https://app.netlify.com/drop**
2. Drag and drop the entire `taskflow` folder onto the page
3. Done! You'll get a live URL like `https://random-name.netlify.app`
4. Click **"Site settings"** → **"Change site name"** to pick a better URL like `taskflow-app.netlify.app`

### Option B: Vercel
1. Go to **https://vercel.com** and sign up with GitHub
2. Install Vercel CLI: open terminal, run `npm i -g vercel`
3. Navigate to the taskflow folder: `cd taskflow`
4. Run `vercel` and follow prompts
5. You'll get a live URL

### Option C: GitHub Pages (free, permanent)
1. Go to **https://github.com** → create account if needed
2. Create a new repository called `taskflow`
3. Upload all files from the `taskflow` folder
4. Go to **Settings → Pages → Source → Deploy from branch → main**
5. Your app will be live at `https://yourusername.github.io/taskflow`

---

## 📱 Step 2: Get on Google Play Store (2-5 days)

### 2a. Create Google Play Developer Account
1. Go to **https://play.google.com/console**
2. Pay the **$25 one-time fee**
3. Complete identity verification (can take 24-48 hours)

### 2b. Generate Android App with PWABuilder
1. Go to **https://www.pwabuilder.com**
2. Paste your live URL from Step 1
3. Click **"Start"** — it will analyze your PWA
4. Click **"Package for stores"** → **"Android"**
5. Fill in:
   - **Package ID**: `com.taskflow.app` (or your preference)
   - **App name**: TaskFlow
   - **App version**: 1.0.0
   - Leave other settings as default
6. Click **"Generate"** — it downloads a `.zip` file
7. Inside the zip you'll find an `.aab` file (Android App Bundle)

### 2c. Upload to Google Play Console
1. In **Google Play Console**, click **"Create app"**
2. Fill in:
   - **App name**: TaskFlow - Smart Task Manager
   - **Default language**: English
   - **App or game**: App
   - **Free or paid**: Free
3. Go to **"Production"** → **"Create new release"**
4. Upload the `.aab` file from PWABuilder
5. Fill in release notes: "Initial release"

### 2d. Complete Store Listing
You need these before Google will review:
- **App title**: TaskFlow - Smart Task Manager
- **Short description** (80 chars): Voice-powered task manager with instant WhatsApp reminders
- **Full description** (4000 chars):

```
TaskFlow is a smart task manager that helps you stay on top of everything with voice input and WhatsApp integration.

🎙️ VOICE INPUT
Just speak your task — TaskFlow automatically detects priority, due dates, and creates the task for you. Say "Call dentist tomorrow urgent" and it's done.

📱 WHATSAPP REMINDERS
Send any task to yourself on WhatsApp with one tap. Send all pending tasks as a daily summary. Never forget a task again.

✅ SMART TASK TRACKING
- Three statuses: To Do, Doing, Done
- Three priority levels: High, Medium, Low
- Due dates with overdue alerts
- Set reminder times for notifications

🔍 SEARCH & FILTER
Quickly find any task with search. Filter by status, view today's tasks, or check overdue items.

📴 WORKS OFFLINE
TaskFlow works even without internet. Your tasks are stored on your device.

Simple. Fast. Free. No account needed.
```

- **Screenshots**: You need 2-8 phone screenshots
  - Open the app on your phone
  - Take screenshots of: main task list, adding a task with voice, WhatsApp send, task details
  - Required size: at least 320px, 16:9 or 9:16 ratio

- **App icon**: Use the 512x512 icon from the `icons` folder

- **Feature graphic** (1024x500): Create one at https://www.canva.com
  - Use a simple design with the app name and a tagline

### 2e. Content Rating & Privacy
1. **Content rating**: Complete the questionnaire (select "Utility" category, no violence/mature content)
2. **Privacy policy**: Required. Create a free one at https://app-privacy-policy-generator.firebaseapp.com/
   - Host it as a page on your site or use a Google Doc (make it public)
3. **Data safety**: Mark that you collect no data (everything stays on device)
4. **Target audience**: Select "18 and above" for simplest approval

### 2f. Submit for Review
1. Make sure all sections show ✅ in the Play Console dashboard
2. Click **"Send for review"**
3. Google reviews new apps in **1-7 days** (usually 1-3)
4. You'll get an email when approved

---

## 📁 Project Files

```
taskflow/
├── index.html        ← The complete app
├── manifest.json     ← PWA configuration
├── sw.js            ← Offline support
└── icons/
    ├── icon-192.png  ← App icon (small)
    └── icon-512.png  ← App icon (large)
```

---

## 🔧 Customization

### Change app name
- Edit `manifest.json` → change "name" and "short_name"
- Edit `index.html` → search for "TaskFlow" and replace

### Change colors
- Edit `index.html` → change CSS variables at the top (--bg, --sf, --tx, etc.)
- Edit `manifest.json` → change "theme_color" and "background_color"

### Change app icon
- Replace `icons/icon-192.png` and `icons/icon-512.png` with your own
- Use https://www.canva.com to design icons
- Must be square PNG, exactly 192x192 and 512x512

---

## 💡 Tips

- **Test on phone first**: Open your Netlify URL on your phone browser, tap "Add to Home Screen" to test as an installed app
- **PWABuilder score**: Before generating the Android app, make sure PWABuilder shows a good score for your PWA
- **Screenshots matter**: Good screenshots dramatically increase downloads
- **Keywords in description**: Include words people search for: "task manager", "to-do list", "WhatsApp reminder", "voice task"
